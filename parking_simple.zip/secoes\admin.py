from django.contrib import admin
from .models import Section, Spot

@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ['nome', 'vagas_cobertas_nominadas', 'vagas_cobertas_nao_nominadas', 
                   'vagas_descobertas_nominadas', 'vagas_descobertas_nao_nominadas']
    search_fields = ['nome']
    list_filter = ['nome']

@admin.register(Spot)
class SpotAdmin(admin.ModelAdmin):
    list_display = ['secao', 'tipo_cobertura', 'nominada', 'status', 'identificador']
    list_filter = ['secao', 'tipo_cobertura', 'nominada', 'status']
    search_fields = ['secao__nome', 'identificador']
    list_editable = ['status']
