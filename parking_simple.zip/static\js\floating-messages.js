// Sistema de Mensagens Flutuantes - Carros em Movimento

class FloatingMessageManager {
    constructor() {
        this.messageQueue = [];
        this.isProcessing = false;
        this.messageCounter = 0;
        this.init();
    }

    init() {
        if (!document.getElementById('floating-messages-container')) {
            const container = document.createElement('div');
            container.id = 'floating-messages-container';
            container.style.cssText = 'position: fixed; top: 0; right: 0; z-index: 10000; pointer-events: none;';
            document.body.appendChild(container);
        }
        this.processDjangoMessages();
    }

    processDjangoMessages() {
        const djangoMessages = document.querySelectorAll('.alert');
        djangoMessages.forEach(message => {
            const messageType = this.getDjangoMessageType(message);
            const messageText = message.textContent.trim();
            if (messageText) {
                this.showMessage(messageText, messageType);
            }
            message.remove();
        });
    }

    getDjangoMessageType(messageElement) {
        const classes = messageElement.className;
        if (classes.includes('alert-success')) return 'success';
        if (classes.includes('alert-danger')) return 'error';
        if (classes.includes('alert-warning')) return 'warning';
        if (classes.includes('alert-info')) return 'info';
        return 'info';
    }

    showMessage(text, type = 'info', duration = 5000) {
        const message = {
            id: `message-${++this.messageCounter}`,
            text: text,
            type: type,
            duration: duration,
            timestamp: Date.now()
        };
        this.messageQueue.push(message);
        this.processQueue();
    }

    processQueue() {
        if (this.isProcessing || this.messageQueue.length === 0) return;
        this.isProcessing = true;
        const message = this.messageQueue.shift();
        this.createMessageElement(message);
    }

    createMessageElement(message) {
        const container = document.getElementById('floating-messages-container');
        const messageElement = document.createElement('div');
        
        messageElement.id = message.id;
        messageElement.className = `floating-message ${message.type}`;
        messageElement.style.pointerEvents = 'auto';
        
        const titles = {
            'success': '✅ Sucesso!',
            'error': '❌ Erro!',
            'warning': '⚠️ Atenção!',
            'info': 'ℹ️ Informação'
        };

        messageElement.innerHTML = `
            <div class="message-content">
                <div class="message-title">${titles[message.type] || titles.info}</div>
                <div class="message-text">${this.escapeHtml(message.text)}</div>
            </div>
            <button class="close-btn" onclick="floatingMessages.closeMessage('${message.id}')">×</button>
        `;

        container.appendChild(messageElement);

        setTimeout(() => {
            this.closeMessage(message.id);
        }, message.duration);

        setTimeout(() => {
            this.isProcessing = false;
            this.processQueue();
        }, 1000);
    }

    closeMessage(messageId) {
        const messageElement = document.getElementById(messageId);
        if (!messageElement) return;
        messageElement.style.animation = 'carDriveOut 0.6s ease-in forwards';
        setTimeout(() => {
            if (messageElement.parentNode) {
                messageElement.parentNode.removeChild(messageElement);
            }
        }, 600);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    success(text, duration) {
        this.showMessage(text, 'success', duration);
    }

    error(text, duration) {
        this.showMessage(text, 'error', duration);
    }

    warning(text, duration) {
        this.showMessage(text, 'warning', duration);
    }

    info(text, duration) {
        this.showMessage(text, 'info', duration);
    }

    clearAll() {
        const container = document.getElementById('floating-messages-container');
        if (container) {
            container.innerHTML = '';
        }
        this.messageQueue = [];
        this.isProcessing = false;
    }
}

const floatingMessages = new FloatingMessageManager();

window.showFloatingMessage = (text, type, duration) => {
    floatingMessages.showMessage(text, type, duration);
};

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        floatingMessages.processDjangoMessages();
    }, 100);
}); 