from django.db import models
from django.core.exceptions import ValidationError
from datetime import datetime

# Create your models here.

class TermoCompromisso(models.Model):
    """Modelo para armazenar múltiplos termos de compromisso por vaga"""
    spot = models.ForeignKey('Spot', on_delete=models.CASCADE, related_name='termos_compromisso')
    arquivo = models.FileField(upload_to='termos_compromisso_vagas/', verbose_name='Arquivo do Termo')
    numero_documento = models.CharField(max_length=20, blank=True, verbose_name='Número do Documento')
    data_upload = models.DateTimeField(auto_now_add=True, verbose_name='Data de Upload')
    observacoes = models.TextField(blank=True, null=True, verbose_name='Observações')
    
    class Meta:
        ordering = ['-data_upload']
        verbose_name = 'Termo de Compromisso'
        verbose_name_plural = 'Termos de Compromisso'
    
    def __str__(self):
        return f"Termo {self.numero_documento} - {self.spot.identificador}"
    
    def save(self, *args, **kwargs):
        if not self.numero_documento:
            self.numero_documento = self.gerar_numero_documento()
        super().save(*args, **kwargs)
    
    def gerar_numero_documento(self):
        """Gera numeração automática: Doc 01, Doc 01 - A01, Doc 01 - A02, etc."""
        # Conta quantos termos já existem para esta vaga
        termos_existentes = TermoCompromisso.objects.filter(spot=self.spot).count()
        
        if termos_existentes == 0:
            # Primeiro documento
            return f"Doc 01"
        else:
            # Documentos adicionais (aditamentos)
            return f"Doc 01 - A{termos_existentes:02d}"

class Section(models.Model):
    NOME_CHOICES = [
        ("Comandante-Geral", "Comandante-Geral"),
        ("Subcomandante-Geral", "Subcomandante-Geral"),
        ("Gabinete do Comandante-Geral", "Gabinete do Comandante-Geral"),
        ("Gabinete do Subcomandante-Geral", "Gabinete do Subcomandante-Geral"),
        ("Comando Operacional de Bombeiros", "Comando Operacional de Bombeiros"),
        ("Ajudância-Geral", "Ajudância-Geral"),
        ("Diretoria de Gestão de Pessoas", "Diretoria de Gestão de Pessoas"),
        ("Diretoria de Ensino, Instrução e Pesquisa", "Diretoria de Ensino, Instrução e Pesquisa"),
        ("Diretoria de Segurança Contra Incêndio", "Diretoria de Segurança Contra Incêndio"),
        ("Diretoria Administrativa e Financeira", "Diretoria Administrativa e Financeira"),
        ("Seção de Inteligência e Contra Inteligência (SEICI)", "Seção de Inteligência e Contra Inteligência (SEICI)"),
        ("Seção de Relações Públicas, Ação Comunitária e Comunicação Social (SERPACS)", "Seção de Relações Públicas, Ação Comunitária e Comunicação Social (SERPACS)"),
        ("Núcleo de Controle Interno - NCI", "Núcleo de Controle Interno - NCI"),
        ("Superior de Dia / Supervisor de Dia", "Superior de Dia / Supervisor de Dia"),
        ("Comandante do Socorro", "Comandante do Socorro"),
        ("Oficial de Dia", "Oficial de Dia"),
    ]
    nome = models.CharField(max_length=100, unique=True)
    vagas_cobertas_nominadas = models.PositiveIntegerField(default=0)
    vagas_cobertas_nao_nominadas = models.PositiveIntegerField(default=0)
    vagas_descobertas_nominadas = models.PositiveIntegerField(default=0)
    vagas_descobertas_nao_nominadas = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.nome

class Spot(models.Model):
    COBERTURA_CHOICES = [
        ("coberta", "Coberta"),
        ("descoberta", "Descoberta"),
    ]
    NOMINADA_CHOICES = [
        ("nominada", "Nominada"),
        ("nao_nominada", "Não Nominada"),
    ]
    STATUS_CHOICES = [
        ("livre", "Livre"),
        ("ocupada", "Ocupada"),
    ]
    POSTO_CHOICES = [
        ('soldado', 'Soldado BM'),
        ('cabo', 'Cabo BM'),
        ('3sgt', '3º Sargento BM'),
        ('2sgt', '2º Sargento BM'),
        ('1sgt', '1º Sargento BM'),
        ('subten', 'Subtenente BM'),
        ('2ten', '2º Tenente BM'),
        ('1ten', '1º Tenente BM'),
        ('cap', 'Capitão BM'),
        ('maj', 'Major BM'),
        ('ten_cel', 'Tenente Coronel BM'),
        ('cel', 'Coronel BM'),
    ]
    TIPO_VEICULO_CHOICES = [
        ('carro', 'Carro'),
        ('moto', 'Moto'),
        ('caminhao', 'Caminhão'),
        ('van', 'Van'),
        ('utilitario', 'Utilitário'),
    ]
    
    # Dados da Vaga
    secao = models.ForeignKey(Section, on_delete=models.CASCADE, related_name="vagas")
    tipo_cobertura = models.CharField(max_length=20, choices=COBERTURA_CHOICES)
    nominada = models.CharField(max_length=20, choices=NOMINADA_CHOICES)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="livre")
    identificador = models.CharField(max_length=20, blank=True, null=True)  # Ex: número da vaga
    ativo = models.BooleanField(default=True, verbose_name="Vaga Ativa")  # Novo campo para controlar se a vaga está ativa
    
    # Dados do Bombeiro Militar
    nome_bombeiro = models.CharField(max_length=100, blank=True, null=True)
    posto_bombeiro = models.CharField(max_length=20, choices=POSTO_CHOICES, blank=True, null=True)
    matricula_bombeiro = models.CharField(max_length=20, blank=True, null=True)
    cpf_bombeiro = models.CharField(max_length=14, blank=True, null=True)  # Formato: 000.000.000-00
    telefone_bombeiro = models.CharField(max_length=20, blank=True, null=True)
    email_bombeiro = models.EmailField(blank=True, null=True)
    
    # Dados do Veículo Principal
    placa_veiculo = models.CharField(max_length=10, blank=True, null=True, unique=True)
    modelo_veiculo = models.CharField(max_length=50, blank=True, null=True)
    marca_veiculo = models.CharField(max_length=50, blank=True, null=True)
    cor_veiculo = models.CharField(max_length=30, blank=True, null=True)
    ano_veiculo = models.PositiveIntegerField(blank=True, null=True)
    tipo_veiculo = models.CharField(max_length=20, choices=TIPO_VEICULO_CHOICES, blank=True, null=True)
    
    # Dados do Veículo Adicional
    placa_veiculo_adicional = models.CharField(max_length=10, blank=True, null=True, unique=True)
    modelo_veiculo_adicional = models.CharField(max_length=50, blank=True, null=True)
    marca_veiculo_adicional = models.CharField(max_length=50, blank=True, null=True)
    cor_veiculo_adicional = models.CharField(max_length=30, blank=True, null=True)
    ano_veiculo_adicional = models.PositiveIntegerField(blank=True, null=True)
    tipo_veiculo_adicional = models.CharField(max_length=20, choices=TIPO_VEICULO_CHOICES, blank=True, null=True)
    
    # Dados da Moto
    placa_moto = models.CharField(max_length=10, blank=True, null=True, unique=True)
    modelo_moto = models.CharField(max_length=50, blank=True, null=True)
    marca_moto = models.CharField(max_length=50, blank=True, null=True)
    cor_moto = models.CharField(max_length=30, blank=True, null=True)
    ano_moto = models.PositiveIntegerField(blank=True, null=True)
    
    # Data de ocupação
    data_ocupacao = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    
    # Data de saída (quando a vaga foi desativada/transferida)
    data_saida = models.DateTimeField(null=True, blank=True, verbose_name="Data de Saída")

    def __str__(self):
        if self.nome_bombeiro and self.placa_veiculo:
            return f"{self.secao.nome} - {self.identificador or 'Sem ID'} - {self.nome_bombeiro} ({self.placa_veiculo})"
        return f"{self.secao.nome} - {self.tipo_cobertura} - {self.nominada} - {self.identificador or 'Sem ID'}"
    
    def clean(self):
        super().clean()
        # Validar se as placas já existem (exceto para o próprio registro)
        placas = [self.placa_veiculo, self.placa_veiculo_adicional, self.placa_moto]
        placas = [p for p in placas if p]  # Remove valores vazios
        
        for placa in placas:
            existing_spot = Spot.objects.filter(
                models.Q(placa_veiculo=placa) |
                models.Q(placa_veiculo_adicional=placa) |
                models.Q(placa_moto=placa)
            ).exclude(pk=self.pk)
            
            if existing_spot.exists():
                raise ValidationError({
                    'placa_veiculo': f'A placa {placa} já está cadastrada no sistema.'
                })
        
        # Validar que não há placas duplicadas no mesmo registro
        placas_unicas = set(placas)
        if len(placas) != len(placas_unicas):
            raise ValidationError({
                'placa_veiculo': 'Não é permitido cadastrar a mesma placa em diferentes campos.'
            })
    
    def gerar_matricula_automatica(self):
        """Gera uma matrícula automática no formato: BM2025-001"""
        ano_atual = datetime.now().year
        
        # Conta quantas matrículas já existem para este ano
        matriculas_existentes = Spot.objects.filter(
            matricula_bombeiro__startswith=f'BM{ano_atual}-'
        ).count()
        
        # Gera o próximo número sequencial
        proximo_numero = matriculas_existentes + 1
        
        return f'BM{ano_atual}-{proximo_numero:03d}'
    
    def save(self, *args, **kwargs):
        # Se tem dados do bombeiro e pelo menos um veículo, marcar como ocupada
        if self.nome_bombeiro and (self.placa_veiculo or self.placa_veiculo_adicional or self.placa_moto):
            self.status = 'ocupada'
        elif not self.nome_bombeiro or not (self.placa_veiculo or self.placa_veiculo_adicional or self.placa_moto):
            # Se não tem bombeiro OU não tem veículos, marcar como livre
            self.status = 'livre'
        super().save(*args, **kwargs)
