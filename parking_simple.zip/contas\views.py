from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView
from django.contrib.auth.forms import SetPasswordForm
from django.core.mail import send_mail
from django.conf import settings
from .models import CustomUser
from .forms import CustomUserCreationForm, CustomUserChangeForm, CustomSetPasswordForm, CustomPasswordResetForm, TermoCompromissoForm
from .mixins import GroupRequiredMixin

# Create your views here.

def login_view(request):
    if request.method == 'POST':
        email = request.POST['username']  # O campo se chama 'username' mas recebe email
        password = request.POST['password']
        
        # Tentar autenticar com email
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Bem-vindo, {user.first_name or user.email}!')
            return redirect('secoes:dashboard')
        else:
            messages.error(request, 'Email ou senha incorretos.')
    return render(request, 'contas/login.html')

@login_required
def logout_view(request):
    logout(request)
    messages.success(request, 'Você saiu do sistema.')
    return redirect('contas:login')

@login_required
def signup_view(request):
    if request.user.tipo_usuario != 'admin':
        messages.error(request, 'Apenas administradores podem cadastrar novos usuários.')
        return redirect('secoes:dashboard')
    
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, f'Usuário {user.email} criado com sucesso!')
            return redirect('contas:user_list')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'contas/signup.html', {'form': form})

@login_required
def change_password_view(request, pk):
    if request.user.tipo_usuario != 'admin':
        messages.error(request, 'Apenas administradores podem alterar senhas.')
        return redirect('secoes:dashboard')
    
    user_to_change = get_object_or_404(CustomUser, pk=pk)
    
    if request.method == 'POST':
        form = CustomSetPasswordForm(user_to_change, request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Senha do usuário {user_to_change.email} alterada com sucesso!')
            return redirect('contas:user_list')
    else:
        form = CustomSetPasswordForm(user_to_change)
    
    return render(request, 'contas/change_password.html', {
        'form': form,
        'user_to_change': user_to_change
    })

@login_required
def upload_termo_compromisso(request):
    if request.method == 'POST':
        form = TermoCompromissoForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Termo de Compromisso enviado com sucesso!')
            return redirect('secoes:dashboard')  # Redirecionar para o dashboard ou outra página
    else:
        form = TermoCompromissoForm(instance=request.user)
    
    return render(request, 'contas/upload_termo.html', {'form': form})

# Views para Recuperação de Senha
class CustomPasswordResetView(PasswordResetView):
    template_name = 'contas/password_reset.html'
    email_template_name = 'contas/password_reset_email.html'
    subject_template_name = 'contas/password_reset_subject.txt'
    success_url = reverse_lazy('contas:password_reset_done')
    form_class = CustomPasswordResetForm
    
    def form_valid(self, form):
        messages.success(self.request, 'Email de recuperação enviado! Verifique sua caixa de entrada.')
        return super().form_valid(form)

class CustomPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'contas/password_reset_done.html'

class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    template_name = 'contas/password_reset_confirm.html'
    success_url = reverse_lazy('contas:password_reset_complete')
    
    def form_valid(self, form):
        messages.success(self.request, 'Senha alterada com sucesso! Você pode fazer login agora.')
        return super().form_valid(form)

class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'contas/password_reset_complete.html'

# CRUD Views para Usuários
class UserListView(LoginRequiredMixin, GroupRequiredMixin, ListView):
    model = CustomUser
    template_name = 'contas/user_list.html'
    context_object_name = 'users'
    allowed_groups = ['admin']
    
    def get_queryset(self):
        return CustomUser.objects.all().order_by('email')

class UserCreateView(LoginRequiredMixin, GroupRequiredMixin, CreateView):
    model = CustomUser
    form_class = CustomUserCreationForm
    template_name = 'contas/user_form.html'
    success_url = reverse_lazy('contas:user_list')
    allowed_groups = ['admin']
    
    def form_valid(self, form):
        messages.success(self.request, 'Usuário criado com sucesso!')
        return super().form_valid(form)

class UserUpdateView(LoginRequiredMixin, GroupRequiredMixin, UpdateView):
    model = CustomUser
    form_class = CustomUserChangeForm
    template_name = 'contas/user_form.html'
    success_url = reverse_lazy('contas:user_list')
    allowed_groups = ['admin']
    
    def form_valid(self, form):
        messages.success(self.request, 'Usuário atualizado com sucesso!')
        return super().form_valid(form)

class UserDeleteView(LoginRequiredMixin, GroupRequiredMixin, DeleteView):
    model = CustomUser
    template_name = 'contas/user_confirm_delete.html'
    success_url = reverse_lazy('contas:user_list')
    allowed_groups = ['admin']
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Usuário excluído com sucesso!')
        return super().delete(request, *args, **kwargs)
