from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, SetPasswordForm
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import PasswordResetForm
from .models import CustomUser

User = get_user_model()

class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('email', 'first_name', 'last_name', 'tipo_usuario')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Remover o campo username se existir
        if 'username' in self.fields:
            del self.fields['username']
        
        # Tornar o email obrigatório
        self.fields['email'].required = True
        self.fields['email'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Digite o email'
        })
        
        # Estilizar outros campos
        for field_name, field in self.fields.items():
            if field_name != 'email':
                field.widget.attrs.update({'class': 'form-control'})

class CustomUserChangeForm(UserChangeForm):
    password = None  # Remover campo de senha da edição
    
    class Meta:
        model = User
        fields = ('email', 'first_name', 'last_name', 'tipo_usuario', 'is_active')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Estilizar campos
        for field_name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control'})

class CustomSetPasswordForm(SetPasswordForm):
    def __init__(self, user, *args, **kwargs):
        super().__init__(user, *args, **kwargs)
        # Estilizar campos
        for field_name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control'})

class CustomPasswordResetForm(PasswordResetForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Estilizar o campo email
        self.fields['email'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Digite seu email'
        })

class TermoCompromissoForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['termo_compromisso_assinado'] 