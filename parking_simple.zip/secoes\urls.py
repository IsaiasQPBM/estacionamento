from django.urls import path
from . import views

app_name = 'secoes'

urlpatterns = [
    # Dashboard (página inicial)
    path('', views.DashboardView.as_view(), name='dashboard'),
    
    # URLs para Seções
    path('secoes/', views.SectionListView.as_view(), name='section_list'),
    path('secao/nova/', views.SectionCreateView.as_view(), name='section_create'),
    path('secao/<int:pk>/editar/', views.SectionUpdateView.as_view(), name='section_update'),
    path('secao/<int:pk>/excluir/', views.SectionDeleteView.as_view(), name='section_delete'),
    
    # URLs para Vagas
    path('vagas/', views.SpotListView.as_view(), name='spot_list'),
    path('vaga/nova/', views.SpotCreateView.as_view(), name='spot_create'),
    path('vaga/<int:pk>/', views.SpotDetailView.as_view(), name='spot_detail'),
    path('vaga/<int:pk>/editar/', views.SpotUpdateView.as_view(), name='spot_update'),
    path('vaga/<int:pk>/excluir/', views.SpotDeleteView.as_view(), name='spot_delete'),
    path('vaga/<int:spot_id>/termo/', views.gerar_termo_compromisso, name='gerar_termo'),
    path('vaga/<int:spot_id>/upload-termo/', views.upload_termo_compromisso_vaga, name='upload_termo_vaga'),
    path('vaga/<int:spot_id>/liberar/', views.liberar_vaga, name='liberar_vaga'),
    path('vaga/<int:spot_id>/desativar/', views.desativar_vaga, name='desativar_vaga'),
    path('vaga/<int:spot_id>/transferir/', views.transferir_vaga, name='transferir_vaga'),
    path('vagas/lista/', views.gerar_lista_vagas, name='gerar_lista_vagas'),
    path('vagas/historico/', views.historico_vagas, name='historico_vagas'),
] 