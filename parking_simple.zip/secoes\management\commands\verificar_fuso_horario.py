from django.core.management.base import BaseCommand
from django.utils import timezone
from django.db import models
from secoes.models import Spot
from datetime import datetime
import pytz

class Command(BaseCommand):
    help = 'Verifica e ajusta o fuso horário das datas no sistema'

    def handle(self, *args, **options):
        # Configurar fuso horário de Brasília
        brasilia_tz = pytz.timezone('America/Sao_Paulo')
        
        self.stdout.write('=== Verificação do Fuso Horário ===')
        self.stdout.write(f'Fuso horário configurado: {timezone.get_current_timezone()}')
        self.stdout.write(f'Data/hora atual (UTC): {timezone.now()}')
        self.stdout.write(f'Data/hora atual (Brasília): {timezone.now().astimezone(brasilia_tz)}')
        
        # Verificar vagas com datas
        vagas_com_datas = Spot.objects.filter(
            models.Q(data_ocupacao__isnull=False) | 
            models.Q(data_saida__isnull=False)
        )
        
        self.stdout.write(f'\nVagas com datas registradas: {vagas_com_datas.count()}')
        
        if vagas_com_datas.exists():
            self.stdout.write('\n=== Exemplos de Datas Registradas ===')
            for vaga in vagas_com_datas[:5]:  # Mostrar apenas 5 exemplos
                self.stdout.write(f'Vaga ID {vaga.id}:')
                if vaga.data_ocupacao:
                    self.stdout.write(f'  - Ocupação: {vaga.data_ocupacao} (UTC) -> {vaga.data_ocupacao.astimezone(brasilia_tz)} (Brasília)')
                if vaga.data_saida:
                    self.stdout.write(f'  - Saída: {vaga.data_saida} (UTC) -> {vaga.data_saida.astimezone(brasilia_tz)} (Brasília)')
        
        # Verificar se há datas que precisam ser ajustadas
        self.stdout.write('\n=== Status do Sistema ===')
        self.stdout.write('✅ Fuso horário configurado para Brasília (America/Sao_Paulo)')
        self.stdout.write('✅ USE_TZ = True (Django salva datas em UTC e converte para exibição)')
        self.stdout.write('✅ Todas as datas serão exibidas automaticamente no horário de Brasília')
        
        # Mostrar exemplo de como as datas aparecem nos templates
        self.stdout.write('\n=== Como as Datas Aparecem nos Templates ===')
        if vagas_com_datas.exists():
            vaga_exemplo = vagas_com_datas.first()
            self.stdout.write(f'Exemplo com vaga ID {vaga_exemplo.id}:')
            if vaga_exemplo.data_ocupacao:
                self.stdout.write(f'  - Template: {{ vaga.data_ocupacao|date:"d/m/Y H:i" }}')
                self.stdout.write(f'  - Resultado: {vaga_exemplo.data_ocupacao.strftime("%d/%m/%Y %H:%M")} (Brasília)')
            if vaga_exemplo.data_saida:
                self.stdout.write(f'  - Template: {{ vaga.data_saida|date:"d/m/Y H:i" }}')
                self.stdout.write(f'  - Resultado: {vaga_exemplo.data_saida.strftime("%d/%m/%Y %H:%M")} (Brasília)')
        
        self.stdout.write('\n✅ Sistema configurado corretamente para o horário de Brasília!') 