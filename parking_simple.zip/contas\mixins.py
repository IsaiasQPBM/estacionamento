from django.core.exceptions import PermissionDenied
from django.contrib.auth.mixins import AccessMixin

class GroupRequiredMixin(AccessMixin):
    """
    Mixin que verifica se o usuário logado pertence a um dos grupos permitidos.
    """
    allowed_groups = []

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return self.handle_no_permission()

        user_type = getattr(request.user, 'tipo_usuario', None)
        if user_type not in self.allowed_groups:
            raise PermissionDenied("Você não tem permissão para acessar esta página.")
        
        return super().dispatch(request, *args, **kwargs) 