from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models

# Create your models here.

class CustomUserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('O email deve ser fornecido')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superusuário precisa ter is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superusuário precisa ter is_superuser=True.')
        return self.create_user(email, password, **extra_fields)

class CustomUser(AbstractUser):
    TIPO_USUARIO_CHOICES = (
        ('admin', 'Admin'),
        ('digitador', 'Digitador'),
        ('usuario', 'Usuário'),
    )
    email = models.EmailField(unique=True)
    tipo_usuario = models.CharField(max_length=10, choices=TIPO_USUARIO_CHOICES, default='usuario')
    termo_compromisso_assinado = models.FileField(upload_to='termos_compromisso/', blank=True, null=True, verbose_name='Termo de Compromisso Assinado')
    
    # Configurar email como campo de identificação para recuperação de senha
    EMAIL_FIELD = 'email'
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']  # Remover email dos campos obrigatórios
    
    username = None  # Remove o campo username

    objects = CustomUserManager()

    def __str__(self):
        return self.email
