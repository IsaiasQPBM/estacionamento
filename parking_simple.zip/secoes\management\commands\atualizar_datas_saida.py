from django.core.management.base import BaseCommand
from secoes.models import Spot
from datetime import datetime

class Command(BaseCommand):
    help = 'Atualiza a data de saída para vagas inativas que não possuem essa informação'

    def handle(self, *args, **options):
        # Buscar vagas inativas sem data de saída
        vagas_sem_data_saida = Spot.objects.filter(
            ativo=False,
            data_saida__isnull=True
        )
        
        if vagas_sem_data_saida.exists():
            self.stdout.write(f'Encontradas {vagas_sem_data_saida.count()} vagas inativas sem data de saída.')
            
            # Atualizar com a data atual (ou usar data de ocupação + 1 dia se disponível)
            for vaga in vagas_sem_data_saida:
                if vaga.data_ocupacao:
                    # Se tem data de ocupação, usar ela + 1 dia como data de saída
                    from datetime import timedelta
                    vaga.data_saida = vaga.data_ocupacao + timedelta(days=1)
                else:
                    # Se não tem data de ocupação, usar data atual
                    vaga.data_saida = datetime.now()
                vaga.save()
            
            self.stdout.write(
                self.style.SUCCESS(f'Data de saída atualizada para {vagas_sem_data_saida.count()} vagas.')
            )
        else:
            self.stdout.write(
                self.style.SUCCESS('Todas as vagas inativas já possuem data de saída.')
            ) 