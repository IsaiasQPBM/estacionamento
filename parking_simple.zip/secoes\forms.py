from django import forms
from .models import Section, Spot, TermoCompromisso

class SectionForm(forms.ModelForm):
    class Meta:
        model = Section
        fields = ['nome', 'vagas_cobertas_nominadas', 'vagas_cobertas_nao_nominadas', 
                 'vagas_descobertas_nominadas', 'vagas_descobertas_nao_nominadas']
        widgets = {
            'nome': forms.TextInput(attrs={
                'class': 'form-control',
                'list': 'secoes-list',
                'placeholder': 'Selecione ou digite uma seção'
            }),
            'vagas_cobertas_nominadas': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
            'vagas_cobertas_nao_nominadas': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
            'vagas_descobertas_nominadas': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
            'vagas_descobertas_nao_nominadas': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Buscar todas as seções existentes para o datalist
        secoes = Section.objects.values_list('nome', flat=True).order_by('nome')
        self.secoes_list = list(secoes)

class SpotForm(forms.ModelForm):
    class Meta:
        model = Spot
        fields = [
            'secao', 'tipo_cobertura', 'nominada', 'identificador',
            'nome_bombeiro', 'posto_bombeiro', 'matricula_bombeiro', 'cpf_bombeiro', 'telefone_bombeiro', 'email_bombeiro',
            'placa_veiculo', 'modelo_veiculo', 'marca_veiculo', 'cor_veiculo', 'ano_veiculo', 'tipo_veiculo',
            'placa_veiculo_adicional', 'modelo_veiculo_adicional', 'marca_veiculo_adicional', 'cor_veiculo_adicional', 'ano_veiculo_adicional', 'tipo_veiculo_adicional',
            'placa_moto', 'modelo_moto', 'marca_moto', 'cor_moto', 'ano_moto'
        ]
        widgets = {
            'secao': forms.Select(attrs={'class': 'form-control'}),
            'tipo_cobertura': forms.Select(attrs={'class': 'form-control'}),
            'nominada': forms.Select(attrs={'class': 'form-control'}),
            'identificador': forms.TextInput(attrs={'class': 'form-control'}),
            
            # Campos do Bombeiro
            'nome_bombeiro': forms.TextInput(attrs={'class': 'form-control'}),
            'posto_bombeiro': forms.Select(attrs={'class': 'form-control'}),
            'matricula_bombeiro': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Digite a matrícula'
            }),
            'cpf_bombeiro': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '000.000.000-00',
                'maxlength': '14'
            }),
            'telefone_bombeiro': forms.TextInput(attrs={'class': 'form-control'}),
            'email_bombeiro': forms.EmailInput(attrs={'class': 'form-control'}),
            
            # Campos do Veículo Principal
            'placa_veiculo': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'ABC-1234'}),
            'modelo_veiculo': forms.TextInput(attrs={'class': 'form-control'}),
            'marca_veiculo': forms.TextInput(attrs={'class': 'form-control'}),
            'cor_veiculo': forms.TextInput(attrs={'class': 'form-control'}),
            'ano_veiculo': forms.NumberInput(attrs={'class': 'form-control', 'min': '1900', 'max': '2030'}),
            'tipo_veiculo': forms.Select(attrs={'class': 'form-control'}),
            
            # Campos do Veículo Adicional
            'placa_veiculo_adicional': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'ABC-1234'}),
            'modelo_veiculo_adicional': forms.TextInput(attrs={'class': 'form-control'}),
            'marca_veiculo_adicional': forms.TextInput(attrs={'class': 'form-control'}),
            'cor_veiculo_adicional': forms.TextInput(attrs={'class': 'form-control'}),
            'ano_veiculo_adicional': forms.NumberInput(attrs={'class': 'form-control', 'min': '1900', 'max': '2030'}),
            'tipo_veiculo_adicional': forms.Select(attrs={'class': 'form-control'}),
            
            # Campos da Moto
            'placa_moto': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'ABC-1234'}),
            'modelo_moto': forms.TextInput(attrs={'class': 'form-control'}),
            'marca_moto': forms.TextInput(attrs={'class': 'form-control'}),
            'cor_moto': forms.TextInput(attrs={'class': 'form-control'}),
            'ano_moto': forms.NumberInput(attrs={'class': 'form-control', 'min': '1900', 'max': '2030'}),
        } 

class TermoCompromissoForm(forms.ModelForm):
    class Meta:
        model = TermoCompromisso
        fields = ['arquivo', 'observacoes']
        widgets = {
            'arquivo': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '.pdf,.doc,.docx'
            }),
            'observacoes': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Observações sobre o documento (opcional)'
            })
        } 