from django.core.management.base import BaseCommand
from secoes.models import Section

class Command(BaseCommand):
    help = 'Popula o banco de dados com as seções do CBMEPI'

    def handle(self, *args, **options):
        secoes = [
            "Comandante-Geral",
            "Subcomandante-Geral",
            "Gabinete do Comandante-Geral",
            "Gabinete do Subcomandante-Geral",
            "Comando Operacional de Bombeiros",
            "Ajudância-Geral",
            "Diretoria de Gestão de Pessoas",
            "Diretoria de Ensino, Instrução e Pesquisa",
            "Diretoria de Segurança Contra Incêndio",
            "Diretoria Administrativa e Financeira",
            "Seção de Inteligência e Contra Inteligência (SEICI)",
            "Seção de Relações Públicas, Ação Comunitária e Comunicação Social (SERPACS)",
            "Núcleo de Controle Interno - NCI",
            "Superior de Dia / Supervisor de Dia",
            "Comandante do Socorro",
            "Oficial de Dia",
        ]

        for nome_secao in secoes:
            section, created = Section.objects.get_or_create(
                nome=nome_secao,
                defaults={
                    'vagas_cobertas_nominadas': 0,
                    'vagas_cobertas_nao_nominadas': 0,
                    'vagas_descobertas_nominadas': 0,
                    'vagas_descobertas_nao_nominadas': 0,
                }
            )
            
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Seção "{nome_secao}" criada com sucesso!')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Seção "{nome_secao}" já existe.')
                )

        self.stdout.write(
            self.style.SUCCESS('Processo de criação das seções concluído!')
        ) 